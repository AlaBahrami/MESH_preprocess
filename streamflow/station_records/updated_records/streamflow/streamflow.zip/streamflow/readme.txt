Note: 
records of station 08MH024 has not been arranged for missing data.
I rearranged them manually


18/5/2021
I have not included the missing records stations I have extracted. I should redo all 91 station